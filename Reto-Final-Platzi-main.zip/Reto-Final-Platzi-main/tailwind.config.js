/** @type {import('tailwindcss').Config} */
module.exports = {
  //archivos de refencia se encontraran en esa ruta
  //creo la carpeta src 
  content: ["./src/**/*.{html,js}"],
  theme: {
    extend: {},
  },
  plugins: [],
}

